# test_plugin

The purpose of this plugin is to provide a simple test plugin for the OmniDB
plugin loader and API. Also it can be used as reference for developing new
plugins.


### Releases

1.0.0: Initial version, compatible with OmniDB core <= 2.11.0

1.1.0: Compatible with OmniDB core >= 2.12.0
