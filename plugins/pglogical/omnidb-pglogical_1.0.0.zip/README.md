# pglogical

This plugin includes in the tree view pglogical relevant nodes, features and actions.


### Releases

1.0.0: Initial version, compatible with OmniDB core >= 2.12.0
